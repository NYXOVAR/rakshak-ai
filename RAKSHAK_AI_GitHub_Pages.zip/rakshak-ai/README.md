# RAKSHAK AI – Defence Safety & Readiness Demo

A responsive, single-page student innovation demo for general safety preparedness, incident documentation, ordinary facility/equipment maintenance records, and checklist tracking.

## Run locally
Open `index.html` in a modern browser. No build tools or dependencies are required.

## Deploy with GitHub Pages
1. Sign in to GitHub and create a **public** repository named `rakshak-ai` (or another name).
2. Choose **Add file → Upload files** and upload `index.html` from this folder.
3. Commit the file to the `main` branch.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Choose branch `main`, folder `/(root)`, then click **Save**.
7. Wait for the Pages deployment to finish. Your site URL will be shown in Settings → Pages, usually `https://YOUR-USERNAME.github.io/rakshak-ai/`.

## Features
- Dashboard with incident, equipment and checklist counts
- Offline rule-based safety assistant (not a generative AI service)
- Incident reporting form and local incident register
- Equipment inspection/maintenance register
- Emergency reference guidance and alert simulation
- Interactive safety checklist with browser persistence
- Export demo records as JSON

## Important limitations
- Records are stored in browser LocalStorage on the current device/browser only.
- There is no login, shared database, server, encryption, access control, or real notification delivery.
- The alert workflow is a simulation and does not contact anyone.
- Do not enter classified, operational, personal, or otherwise sensitive information.
- This is an educational demonstration, not an official military system or substitute for approved emergency procedures or professional advice.
